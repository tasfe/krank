package test.junit;

import junit.framework.TestCase;

public class TestAa extends TestCase {

  public void testAa1() {
    
  }
}
