package test.failures;

import org.testng.annotations.Test;

public class Base0 {
  @Test
  public void base1() {
      assert true;
  }


}
