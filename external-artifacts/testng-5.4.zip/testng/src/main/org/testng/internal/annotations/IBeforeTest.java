package org.testng.internal.annotations;

public interface IBeforeTest extends IBaseBeforeAfter {

}
