package test.junit.testsetup;

public class Data
{
	public int i = 3;
}
