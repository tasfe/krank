package test.junit;

import junit.framework.TestCase;

public class TestAd extends TestCase {

  public void testAd1() {
    
  }
}
