package test.junit;

import junit.framework.TestCase;

public class TestAb extends TestCase {

  public void testAb1() {
    
  }
}
