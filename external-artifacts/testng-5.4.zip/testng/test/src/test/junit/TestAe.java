package test.junit;

import junit.framework.TestCase;

public class TestAe extends TestCase {

  public void testAe1() {
    
  }
}
