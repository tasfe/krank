package test.junit;

import junit.framework.TestCase;

public class TestAf extends TestCase {

  public void testAf1() {
    
  }
}
