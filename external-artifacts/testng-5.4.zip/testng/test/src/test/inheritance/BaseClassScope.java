package test.inheritance;

import org.testng.annotations.Test;

@Test
public class BaseClassScope {
}
