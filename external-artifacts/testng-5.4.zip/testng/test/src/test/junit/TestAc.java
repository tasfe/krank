package test.junit;

import junit.framework.TestCase;

public class TestAc extends TestCase {

  public void testAc1() {
    
  }
}
